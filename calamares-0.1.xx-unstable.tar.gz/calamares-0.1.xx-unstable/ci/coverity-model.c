/* Model file for Coverity checker.
  See https://scan.coverity.com/tune

  Calamares doesn't seem to geenerate any false positives,
  so the model-file is empty.

  SPDX-FileCopyrightText: 2017 Adriaan de Groot <groot@kde.org>
  SPDX-License-Identifier: BSD-2-Clause
*/
